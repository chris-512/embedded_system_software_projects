#ifndef _DEBUG_HEADER_
#define _DEBUG_HEADER_

#include <stdio.h>
#include <stdarg.h>

void DEBUG(const char *debug, ...);

#endif
