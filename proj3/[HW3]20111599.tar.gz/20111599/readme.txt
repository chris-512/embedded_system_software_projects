device name         : /dev/stopwatch
device major number : 245
