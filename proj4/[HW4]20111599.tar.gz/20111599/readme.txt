Android app with 2 activities


Activity

1. StartScreen.java
    The first activity that comes up when app is run.
    It provides a button which can be pressed to 
    initiate the slide puzzle game.

2. SlidePuzzle.java
    The activity that provides a slide puzzle game.
    First, you insert row, col information about your slide
    puzzle on EditText.
    Then, you press "Make Buttons" button on the screen.
    It will then give you random slide puzzle according
    to your given row and col.
    You can press the slide puzzle button to move around
    your puzzle until you get the right order of your slide
    puzzle.
    Finally, when you get to the answer, the app will
    print out "Congratulations!" on your screen, and
    will go back to the the StartScreen activity.
